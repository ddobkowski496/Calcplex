# Calculator site: easy deployment guide

This folder contains the whole website. It is a small static site, so you do not need to install anything or run a build command.

## What the files do

- `index.html` is the page you open.
- `app.js` makes the calculator, graph, hidden games/apps page, and automatic cloud save work.
- `assets/` contains local app-logo fallbacks used in the hidden launcher. The launcher also loads current site favicons when online.
- `README.md` is this guide.

Keep `index.html`, `app.js`, and `README.md` together at the top level of the GitHub repository, and keep the `assets` folder beside them.

## Put it on Cloudflare Pages

1. Sign in to [Cloudflare](https://dash.cloudflare.com/).
2. Open **Workers & Pages**.
3. Click **Create application**, choose **Pages**, then choose **Import an existing Git repository**.
4. Connect GitHub if Cloudflare asks, and select the repository that contains these files.
5. In the setup screen, use these settings:

   - **Production branch:** `main`
   - **Framework preset:** `None` (or **No framework**)
   - **Build command:** `exit 0`
   - **Build output directory:** `.`
   - **Root directory:** leave the default / blank

6. Click **Save and Deploy** (or **Deploy**).
7. Wait for the deployment to finish, then open the `*.pages.dev` address Cloudflare shows you.

Cloudflare will deploy updates automatically whenever new changes are pushed to the `main` branch. The site needs `index.html` and `app.js` together at the repository root; if you see a 404, check that they are not inside an extra folder.

## Cloud save

The site is configured for the Supabase project and automatically creates an anonymous session. Visitors do not create a website account. Cloud save belongs to that browser, so it will not transfer to a different device or browser.

The Supabase project must have the `calculator_saves` table, row-level security policy, and anonymous sign-ins enabled. Those are set up for the current project. The publishable Supabase key in `app.js` is designed to be used in a website; never put a Supabase **service-role** key in this repository.

If the page says cloud save is unavailable, check that the Supabase project is active, anonymous sign-ins are enabled, and the `calculator_saves` table is present. Saves still work in the current browser while cloud sync is unavailable.

## Use the hidden games/apps page

The public page shows only the calculator. Type `0000` into the calculator and press Enter (or tap the calculator keys) to open the hidden games and apps page in a new `about:blank` tab. Choose game or app cards to load them in the built-in player. Each choice gets its own switchable player tab, so you can keep several open. Add up to three games with a name, full game URL, and optional logo image URL; entries save automatically in the browser and to Supabase when cloud save is available. Each app has its own site address and app logo image. If an app blocks the embedded player, use **Open site in a new tab**. This is not a proxy and cannot bypass network restrictions.

## Important browser note

The secret tab opens as `about:blank` when `0000` is entered. A website cannot guarantee that browser activity is hidden from history.

## Need help?

Cloudflare's official walkthrough is [Deploy a static HTML site with Pages](https://developers.cloudflare.com/pages/framework-guides/deploy-anything/).
